<!-- View Message -->
<div class="modal fade" id="viewMessage">
    <div class="modal-dialog">
        <div class="modal-content">
          	<div class="modal-header bg-blue">
            	<h4 class="modal-title">Sender id/name: <strong> <i class="from"></strong></i></h4>
          	</div>
              
          	<div class="modal-body">
            
                <div class='col-sm-12 bg-gray'>
                  <div class="form-group col-sm-12">
                      <h4><p class="text"></p></h4>
                      <h6><i class="date"></i></h6>
                </div>
          	</div>
       <hr>
          	<div class="modal-footer">
            <button type="button" class="btn btn-default btn-sm btn-flat" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
          	
          	</div>
        </div>
    </div>
</div><!-- /View Message -->
