<footer class="main-footer bg-gray">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 2020 Brought To You By<a href="#"> zWarLorDz</a></strong>
</footer>
