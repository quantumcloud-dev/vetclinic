<?php
	include 'includes/session.php';

	if(isset($_POST['message_delete'])){
		$id = $_POST['id'];
		
		$conn = $pdo->open();

		try{
            $note = $conn->prepare("UPDATE messages SET 
			message_status=:message_status
			WHERE id=:id");

			$note->execute(['message_status'=>'Deleted', 'id'=>$id]);

			$_SESSION['success'] = 'Message Deleted.';
		}
		catch(PDOException $e){
			// $_SESSION['error'] = $e->getMessage();
		}

		$pdo->close();
	}
	else{
		// $_SESSION['error'] = 'Select category to delete first';
	}

	header('location: inbox.php');
	
?>