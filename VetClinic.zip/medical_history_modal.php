<!-- Edit Profile -->
<div class="modal fade" id="edit">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header"  style="background-color:darkviolet; color:white;">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title"><b>Update Account</b></h4>
            </div>
            <div class="modal-body">
                <a href="services.php" type="button" class="btn btn-default btn-flat" data-dismiss="modal">
                    <i class="fa fa-close"></i> Consultation</a>
                <a href="services.php" class="btn btn-default btn-flat" data-dismiss="modal">
                    <i class="fa fa-close"></i> Vaccination</a>
                <a href="services.php" class="btn btn-default btn-flat" data-dismiss="modal">
                    <i class="fa fa-close"></i> Grooming</a>
            </div>
        </div>
    </div>
</div>