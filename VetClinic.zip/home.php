<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">
<?php include 'session.php'; ?>

	<?php include 'includes/navbar.php'; ?>

	  	<div class="content-wrapper">
			<div class="container">
				<div class="content text-center">
					<div class="col-sm-12">
						<div class="row">
						<div class="col-md-12"> 
						<div class="panel">
							<div class="panel-body">
							<!--/stories-->
							<div class="row">    
								<br>
								
							</div>
							<hr>
							</div>
						</div>
						</div><!--/col-12-->
						
					</div>
					
			</div>
		</div>
	     
	    </div>
	  </div>
  
  	<?php include 'includes/footer.php';
	  include 'profile_modal.php'; ?>
	  
</div>

<?php include 'includes/scripts.php'; ?>
</body>
</html>